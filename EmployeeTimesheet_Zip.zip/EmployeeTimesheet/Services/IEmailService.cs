using System.Threading.Tasks;

public interface IEmailService
{
    Task SendTimesheetRemindersAsync();
}
